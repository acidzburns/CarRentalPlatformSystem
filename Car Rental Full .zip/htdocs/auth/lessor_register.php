<?php
require_once '../config/database.php';
require_once '../config/session.php';
redirect_if_logged_in();

$error = "";
$success = "";
$name = $email = $phone = $business_name = $bank_account = "";
$uploaded_file_names = ['driver_license' => '', 'vehicle_ownership' => '', 'insurance' => ''];

// Form processing (unchanged from your original code)
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    $business_name = trim($_POST['business_name']);
    $bank_account = trim($_POST['bank_account']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $terms = isset($_POST['terms']) ? true : false;

    // Validation & file upload logic here (same as original)
    // ...
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Car Owner Registration</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
<style>
    body {
        font-family: 'Inter', sans-serif;
        background: #f5f6fa;
        margin: 0;
        padding: 0;
    }
    .container {
        max-width: 700px;
        margin: 50px auto;
        background: #fff;
        padding: 40px;
        border-radius: 12px;
        box-shadow: 0 8px 25px rgba(0,0,0,0.1);
    }
    h1 {
        text-align: center;
        color: #2f3640;
        margin-bottom: 10px;
    }
    p.subtitle {
        text-align: center;
        color: #718093;
        margin-bottom: 30px;
    }
    .form-group {
        margin-bottom: 20px;
    }
    .form-group label {
        display: block;
        font-weight: 600;
        margin-bottom: 6px;
    }
    .form-group input[type="text"],
    .form-group input[type="email"],
    .form-group input[type="tel"],
    .form-group input[type="password"],
    .form-group input[type="file"] {
        width: 100%;
        padding: 10px 12px;
        border: 1px solid #dcdde1;
        border-radius: 6px;
        font-size: 14px;
        transition: 0.3s;
    }
    .form-group input:focus {
        border-color: #0097e6;
        outline: none;
    }
    .form-group small {
        color: #718093;
    }
    .file-display {
        display: inline-block;
        margin-top: 5px;
        font-size: 13px;
        color: #2f3640;
    }
    .file-clear-btn {
        margin-left: 10px;
        font-size: 12px;
        padding: 3px 8px;
        border: none;
        background: #e84118;
        color: #fff;
        border-radius: 4px;
        cursor: pointer;
    }
    .file-clear-btn:hover {
        background: #c23616;
    }
    .checkbox-group {
        margin-bottom: 20px;
    }
    .checkbox-group input {
        margin-right: 10px;
    }
    button.submit-btn {
        width: 100%;
        padding: 12px;
        background: #0097e6;
        color: #fff;
        font-weight: 600;
        font-size: 16px;
        border: none;
        border-radius: 8px;
        cursor: pointer;
        transition: 0.3s;
    }
    button.submit-btn:hover {
        background: #0984e3;
    }
    .links {
        margin-top: 25px;
        text-align: center;
        font-size: 14px;
    }
    .links a {
        color: #0097e6;
        text-decoration: none;
        margin: 0 8px;
    }
    .links a:hover {
        text-decoration: underline;
    }
    .error, .success {
        padding: 12px;
        border-radius: 8px;
        margin-bottom: 20px;
        font-weight: 500;
    }
    .error {
        background: #ff4d4d;
        color: #fff;
    }
    .success {
        background: #44bd32;
        color: #fff;
    }
</style>
<script>
function clearFile(inputId, displayId) {
    document.getElementById(inputId).value = '';
    document.getElementById(displayId).textContent = '';
}
function displayFileName(inputId, displayId) {
    const input = document.getElementById(inputId);
    const display = document.getElementById(displayId);
    if (input.files && input.files[0]) {
        const fileName = input.files[0].name;
        const fileSize = (input.files[0].size / 1024 / 1024).toFixed(2);
        display.textContent = fileName + ' (' + fileSize + ' MB)';
    } else {
        display.textContent = '';
    }
}
</script>
</head>
<body>
<div class="container">
    <h1>Car Owner Registration</h1>
    <p class="subtitle">Register to list your vehicles and start earning</p>

    <?php if ($error): ?>
        <div class="error"><?php echo $error; ?></div>
    <?php endif; ?>

    <?php if ($success): ?>
        <div class="success"><?php echo $success; ?></div>
        <p class="links"><a href="lessor_login.php">Click here to login</a></p>
    <?php else: ?>
    <form method="POST" enctype="multipart/form-data">
        <h2>Personal Information</h2>
        <div class="form-group">
            <label for="name">Full Name *</label>
            <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($name); ?>" required>
        </div>
        <div class="form-group">
            <label for="email">Email Address *</label>
            <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($email); ?>" required>
        </div>
        <div class="form-group">
            <label for="phone">Phone Number *</label>
            <input type="tel" id="phone" name="phone" value="<?php echo htmlspecialchars($phone); ?>" required>
        </div>

        <h2>Business Details (Optional)</h2>
        <div class="form-group">
            <label for="business_name">Business Name</label>
            <input type="text" id="business_name" name="business_name" value="<?php echo htmlspecialchars($business_name); ?>">
        </div>
        <div class="form-group">
            <label for="bank_account">Bank Account Number</label>
            <input type="text" id="bank_account" name="bank_account" value="<?php echo htmlspecialchars($bank_account); ?>">
            <small>For receiving payments</small>
        </div>

        <h2>Required Documents</h2>
        <p>Please upload clear copies (PDF, JPG, PNG, max 5MB each):</p>
        <div class="form-group">
            <label for="driver_license">Driver's License *</label>
            <input type="file" id="driver_license" name="driver_license" accept=".pdf,.jpg,.jpeg,.png" required onchange="displayFileName('driver_license', 'driver_license_display')">
            <span id="driver_license_display" class="file-display"></span>
            <button type="button" class="file-clear-btn" onclick="clearFile('driver_license', 'driver_license_display')">Clear</button>
        </div>
        <div class="form-group">
            <label for="vehicle_ownership">Vehicle Ownership Ceritificate*</label>
            <input type="file" id="vehicle_ownership" name="vehicle_ownership" accept=".pdf,.jpg,.jpeg,.png" required onchange="displayFileName('vehicle_ownership', 'vehicle_ownership_display')">
            <span id="vehicle_ownership_display" class="file-display"></span>
            <button type="button" class="file-clear-btn" onclick="clearFile('vehicle_ownership', 'vehicle_ownership_display')">Clear</button>
        </div>
        <div class="form-group">
            <label for="insurance">Insurance Cover Note *</label>
            <input type="file" id="insurance" name="insurance" accept=".pdf,.jpg,.jpeg,.png" required onchange="displayFileName('insurance', 'insurance_display')">
            <span id="insurance_display" class="file-display"></span>
            <button type="button" class="file-clear-btn" onclick="clearFile('insurance', 'insurance_display')">Clear</button>
        </div>

        <h2>Account Security</h2>
        <div class="form-group">
            <label for="password">Password *</label>
            <input type="password" id="password" name="password" required>
            <small>At least 8 characters with letters, numbers, and special characters</small>
        </div>
        <div class="form-group">
            <label for="confirm_password">Confirm Password *</label>
            <input type="password" id="confirm_password" name="confirm_password" required>
        </div>

        <div class="checkbox-group">
            <label>
                <input type="checkbox" name="terms" required>
                I agree to the Terms and Conditions *
            </label>
        </div>

        <button type="submit" class="submit-btn">Register</button>
    </form>
    <?php endif; ?>

    <div class="links">
        Already have an account? <a href="lessor_login.php">Login here</a><br>
        <a href="renter_login.php">Login as Customer</a> | 
        <a href="../index.php">Back to Home</a>
    </div>
</div>
</body>
</html>
