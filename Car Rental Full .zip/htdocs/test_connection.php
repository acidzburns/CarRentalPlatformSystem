<?php
// This line connects to the database.php file
require_once 'config/database.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Database Connection Test</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 800px; margin: 50px auto; padding: 20px; background-color: #f5f5f5; }
        .success { background-color: #d4edda; color: #155724; padding: 15px; border: 1px solid #c3e6cb; border-radius: 5px; margin: 10px 0; }
        .error { background-color: #f8d7da; color: #721c24; padding: 15px; border: 1px solid #f5c6cb; border-radius: 5px; margin: 10px 0; }
        .info { background-color: #d1ecf1; color: #0c5460; padding: 15px; border: 1px solid #bee5eb; border-radius: 5px; margin: 10px 0; }
        table { width: 100%; border-collapse: collapse; margin: 20px 0; background-color: white; }
        th, td { padding: 12px; text-align: left; border: 1px solid #ddd; }
        th { background-color: #007bff; color: white; }
        .test-section { background-color: white; padding: 20px; margin: 20px 0; border-radius: 5px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
    </style>
</head>
<body>
    <h1>🔌 Database Connection Test</h1>
    
    <div class="test-section">
        <h2>Test 1: Connection Status</h2>
        <?php if ($conn): ?>
            <div class="success">✅ Database connection successful!</div>
            <div class="info">
                Host: <?php echo DB_HOST; ?><br>
                Service: <?php echo DB_SERVICE_NAME; ?><br>
                User: <?php echo DB_USERNAME; ?>
            </div>
        <?php else: ?>
            <div class="error">❌ Database connection failed! Check your credentials.</div>
            <?php exit; ?>
        <?php endif; ?>
    </div>

    <div class="test-section">
        <h2>Test 2: Database Tables</h2>
        <?php
        $tables = db_query("SELECT table_name FROM user_tables ORDER BY table_name");
        if ($tables):
        ?>
            <div class="success">✅ Found <?php echo count($tables); ?> tables</div>
            <table>
                <tr><th>#</th><th>Table Name</th></tr>
                <?php $i = 1; foreach ($tables as $table): ?>
                    <tr><td><?php echo $i++; ?></td><td><?php echo $table['TABLE_NAME']; ?></td></tr>
                <?php endforeach; ?>
            </table>
        <?php else: ?>
            <div class="error">❌ No tables found! Run your carrental2.sql file in SQL Developer.</div>
        <?php endif; ?>
    </div>

    <div class="test-section">
        <h2>Test 3: Sequences</h2>
        <?php
        $sequences = db_query("SELECT sequence_name FROM user_sequences ORDER BY sequence_name");
        if ($sequences):
        ?>
            <div class="success">✅ Found <?php echo count($sequences); ?> sequences</div>
            <table>
                <tr><th>#</th><th>Sequence Name</th></tr>
                <?php $i = 1; foreach ($sequences as $seq): ?>
                    <tr><td><?php echo $i++; ?></td><td><?php echo $seq['SEQUENCE_NAME']; ?></td></tr>
                <?php endforeach; ?>
            </table>
        <?php else: ?>
            <div class="error">❌ No sequences found!</div>
        <?php endif; ?>
    </div>
</body>
</html>