<?php
/**
 * UC25: Customer Support - Admin Manage Tickets
 * Backend functionality only
 */
session_start();
require_once '../config/database.php';
require_once '../config/session.php';
require_once '../includes/check_auth.php';
require_once '../config/email_test.php';

check_authentication('admin');

$admin_id = get_user_id();
$admin_name = get_user_name();

// Handle ticket actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $ticket_id = $_POST['ticket_id'] ?? 0;
    
    if ($action === 'resolve' && $ticket_id > 0) {
        // UC25: Resolve ticket
        $resolution = trim($_POST['resolution'] ?? '');
        
        if (empty($resolution)) {
            $_SESSION['error'] = 'Please provide resolution details.';
        } else {
            $update_query = "UPDATE TICKET 
                            SET STATUS = 'RESOLVED'
                            WHERE TICKETID = :ticketid";
            
            if (db_execute($update_query, ['ticketid' => $ticket_id])) {
                $_SESSION['success'] = 'Ticket #' . $ticket_id . ' has been resolved.';
                
                // --- EMAIL NOTIFICATION TO USER ---
                $ticket_info = db_fetch_one("SELECT RENTERID, LESSORID, SUBJECT, DESCRIPTION 
                                             FROM TICKET WHERE TICKETID = :ticketid", 
                                             ['ticketid' => $ticket_id]);

                if ($ticket_info) {
                    if (!empty($ticket_info['RENTERID'])) {
                        $user_email = db_fetch_one("SELECT EMAIL, NAME FROM RENTER WHERE RENTERID = :id", ['id' => $ticket_info['RENTERID']]);
                        $user_name = $user_email['NAME'] ?? 'Renter';
                        $to_email = $user_email['EMAIL'];
                    } elseif (!empty($ticket_info['LESSORID'])) {
                        $user_email = db_fetch_one("SELECT EMAIL, NAME FROM LESSOR WHERE LESSORID = :id", ['id' => $ticket_info['LESSORID']]);
                        $user_name = $user_email['NAME'] ?? 'Lessor';
                        $to_email = $user_email['EMAIL'];
                    }
                    
                    if (!empty($to_email)) {
                        $subject_email = "Your Support Ticket #$ticket_id has been resolved";
                        $body_email = "
                            <p>Hello {$user_name},</p>
                            <p>Your support ticket <strong>#{$ticket_id}</strong> has been resolved by the admin.</p>
                            <p><strong>Subject:</strong> {$ticket_info['SUBJECT']}</p>
                            <p><strong>Description:</strong><br>" . nl2br(htmlspecialchars($ticket_info['DESCRIPTION'])) . "</p>
                            <p>If you have further issues, please reply or submit a new ticket.</p>
                            <p>Thank you,<br>Car Rental Platform Team</p>
                        ";

                        send_email($to_email, $subject_email, $body_email);
                    }
                }
            } else {
                $_SESSION['error'] = 'Failed to resolve ticket.';
            }
        }
    }
    elseif ($action === 'reopen' && $ticket_id > 0) {
        // Reopen ticket
        $update_query = "UPDATE TICKET 
                        SET STATUS = 'OPEN'
                        WHERE TICKETID = :ticketid";
        
        if (db_execute($update_query, ['ticketid' => $ticket_id])) {
            $_SESSION['success'] = 'Ticket #' . $ticket_id . ' has been reopened.';
        } else {
            $_SESSION['error'] = 'Failed to reopen ticket.';
        }
    }
    elseif ($action === 'assign' && $ticket_id > 0) {
        // Assign ticket to current admin
        $update_query = "UPDATE TICKET 
                        SET ADMINID = :adminid
                        WHERE TICKETID = :ticketid";
        
        if (db_execute($update_query, ['adminid' => $admin_id, 'ticketid' => $ticket_id])) {
            $_SESSION['success'] = 'Ticket #' . $ticket_id . ' assigned to you.';
        } else {
            $_SESSION['error'] = 'Failed to assign ticket.';
        }
    }
    
    header('Location: manage_tickets.php');
    exit;
}

// Filter by status
$status_filter = $_GET['status'] ?? 'OPEN';

// Fetch tickets
$query = "SELECT t.*, 
          TO_CHAR(t.CREATED_AT, 'DD-MON-YYYY HH24:MI') as CREATED_AT_F,
          a.NAME as ADMIN_NAME,
          r.NAME as RENTER_NAME,
          r.EMAIL as RENTER_EMAIL,
          l.NAME as LESSOR_NAME,
          l.EMAIL as LESSOR_EMAIL,
          CASE 
            WHEN t.RENTERID IS NOT NULL THEN 'Renter'
            WHEN t.LESSORID IS NOT NULL THEN 'Lessor'
            ELSE 'Unknown'
          END as USER_TYPE
          FROM TICKET t
          LEFT JOIN ADMIN a ON t.ADMINID = a.ADMINID
          LEFT JOIN RENTER r ON t.RENTERID = r.RENTERID
          LEFT JOIN LESSOR l ON t.LESSORID = l.LESSORID";

if ($status_filter !== 'ALL') {
    $query .= " WHERE t.STATUS = :status";
}

$query .= " ORDER BY t.CREATED_AT DESC";

$params = ($status_filter !== 'ALL') ? ['status' => $status_filter] : [];
$tickets = db_fetch_all($query, $params);

// Count by status
$count_query = "SELECT STATUS, COUNT(*) as CNT FROM TICKET GROUP BY STATUS";
$counts = db_fetch_all($count_query);
$status_counts = [];
foreach ($counts as $row) {
    $status_counts[$row['STATUS']] = $row['CNT'];
}
$total_tickets = array_sum($status_counts);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Support Tickets - Admin</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/manage_tickets.css">
</head>
<body>
    <div class="container">
        <!-- Header -->
        <div class="header">
            <div class="header-content">
                <h1>🎫 Support Ticket Management</h1>
                <p class="admin-info">Admin: <?php echo htmlspecialchars($admin_name); ?></p>
            </div>
            <nav class="nav">
                <a href="dashboard.php">Dashboard</a>
                <a href="verify_lessors.php">Verify Lessors</a>
                <a href="manage_users.php">Manage Users</a>
                <a href="manage_tickets.php" class="active">Support Tickets</a>
                <a href="reports.php">Reports</a>
                <a href="../auth/logout.php">Logout</a>
            </nav>
        </div>

        <!-- Alert Messages -->
        <?php if (isset($_SESSION['success'])): ?>
            <div class="alert success">
                <strong>✓ Success!</strong> <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
            </div>
        <?php endif; ?>
        
        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert error">
                <strong>❌ Error!</strong> <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
            </div>
        <?php endif; ?>

        <!-- Statistics Section -->
        <div class="stats-section">
            <h2>📊 Tickets Overview</h2>
            <div class="stats-grid">
                <div class="stat-box total">
                    <div class="stat-value"><?php echo $total_tickets; ?></div>
                    <div class="stat-label">Total Tickets</div>
                </div>
                <div class="stat-box open">
                    <div class="stat-value"><?php echo $status_counts['OPEN'] ?? 0; ?></div>
                    <div class="stat-label">Open Tickets</div>
                </div>
                <div class="stat-box resolved">
                    <div class="stat-value"><?php echo $status_counts['RESOLVED'] ?? 0; ?></div>
                    <div class="stat-label">Resolved Tickets</div>
                </div>
            </div>
        </div>

        <!-- Filter Section -->
        <div class="filter-section">
            <p>Filter by Status:</p>
            <div class="filter-buttons">
                <a href="?status=ALL" class="filter-btn <?php echo $status_filter === 'ALL' ? 'active' : ''; ?>">
                    All (<?php echo $total_tickets; ?>)
                </a>
                <a href="?status=OPEN" class="filter-btn <?php echo $status_filter === 'OPEN' ? 'active' : ''; ?>">
                    ⚠ Open (<?php echo $status_counts['OPEN'] ?? 0; ?>)
                </a>
                <a href="?status=RESOLVED" class="filter-btn <?php echo $status_filter === 'RESOLVED' ? 'active' : ''; ?>">
                    ✓ Resolved (<?php echo $status_counts['RESOLVED'] ?? 0; ?>)
                </a>
            </div>
        </div>

        <!-- Tickets Section -->
        <div class="tickets-section">
            <h2>🎫 Support Tickets (<?php echo count($tickets); ?>)</h2>
            
            <?php if (empty($tickets)): ?>
                <div class="empty-state">
                    <svg fill="currentColor" viewBox="0 0 20 20">
                        <path d="M9 2a1 1 0 000 2h2a1 1 0 100-2H9z"/>
                        <path fill-rule="evenodd" d="M4 5a2 2 0 012-2 3 3 0 003 3h2a3 3 0 003-3 2 2 0 012 2v11a2 2 0 01-2 2H6a2 2 0 01-2-2V5zm3 4a1 1 0 000 2h.01a1 1 0 100-2H7zm3 0a1 1 0 000 2h3a1 1 0 100-2h-3zm-3 4a1 1 0 100 2h.01a1 1 0 100-2H7zm3 0a1 1 0 100 2h3a1 1 0 100-2h-3z" clip-rule="evenodd"/>
                    </svg>
                    <h3>No Tickets Found</h3>
                    <p>There are no tickets matching your current filter.</p>
                </div>
            <?php else: ?>
                <?php foreach ($tickets as $ticket): ?>
                <div class="ticket-card">
                    <div class="ticket-header">
                        <div class="ticket-info">
                            <h3 class="ticket-title">
                                TICKET-<?php echo $ticket['TICKETID']; ?>: 
                                <?php echo htmlspecialchars($ticket['SUBJECT']); ?>
                            </h3>
                            <div class="ticket-meta">
                                <div>
                                    <strong>From:</strong> 
                                    <?php 
                                    if ($ticket['RENTERID']) {
                                        echo htmlspecialchars($ticket['RENTER_NAME']) . ' (Renter) - ' . htmlspecialchars($ticket['RENTER_EMAIL']);
                                    } elseif ($ticket['LESSORID']) {
                                        echo htmlspecialchars($ticket['LESSOR_NAME']) . ' (Lessor) - ' . htmlspecialchars($ticket['LESSOR_EMAIL']);
                                    }
                                    ?>
                                </div>
                                <div>
                                    <strong>Submitted:</strong> <?php echo $ticket['CREATED_AT_F']; ?>
                                </div>
                                <div>
                                    <strong>Assigned To:</strong> <?php echo htmlspecialchars($ticket['ADMIN_NAME'] ?? 'Unassigned'); ?>
                                </div>
                            </div>
                        </div>
                        <div>
                            <?php if ($ticket['STATUS'] === 'OPEN'): ?>
                                <span class="ticket-status open">⚠ OPEN</span>
                            <?php else: ?>
                                <span class="ticket-status resolved">✓ RESOLVED</span>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="ticket-description">
                        <strong>Description:</strong>
                        <?php echo nl2br(htmlspecialchars($ticket['DESCRIPTION'])); ?>
                    </div>
                    
                    <!-- Actions -->
                    <div class="ticket-actions">
                        <?php if ($ticket['STATUS'] === 'OPEN'): ?>
                            <?php if ($ticket['ADMINID'] != $admin_id): ?>
                                <form method="POST" style="display: inline;">
                                    <input type="hidden" name="action" value="assign">
                                    <input type="hidden" name="ticket_id" value="<?php echo $ticket['TICKETID']; ?>">
                                    <button type="submit" class="btn btn-assign">
                                        👤 Assign to Me
                                    </button>
                                </form>
                            <?php endif; ?>
                            
                            <button onclick="toggleResolutionForm(<?php echo $ticket['TICKETID']; ?>)" class="btn btn-resolve">
                                ✓ Resolve Ticket
                            </button>
                        <?php else: ?>
                            <form method="POST" style="display: inline;">
                                <input type="hidden" name="action" value="reopen">
                                <input type="hidden" name="ticket_id" value="<?php echo $ticket['TICKETID']; ?>">
                                <button type="submit" class="btn btn-reopen">
                                    🔄 Reopen Ticket
                                </button>
                            </form>
                        <?php endif; ?>
                    </div>
                    
                    <!-- Resolution Form (Hidden) -->
                    <?php if ($ticket['STATUS'] === 'OPEN'): ?>
                    <div id="resolve_<?php echo $ticket['TICKETID']; ?>" class="resolution-form">
                        <form method="POST">
                            <input type="hidden" name="action" value="resolve">
                            <input type="hidden" name="ticket_id" value="<?php echo $ticket['TICKETID']; ?>">
                            
                            <label>Resolution Notes:</label>
                            <textarea name="resolution" rows="4" required
                                      placeholder="Describe how you resolved this issue..."></textarea>
                            
                            <div class="form-actions">
                                <button type="submit" class="btn btn-resolve">
                                    ✓ Confirm Resolution
                                </button>
                                <button type="button" onclick="toggleResolutionForm(<?php echo $ticket['TICKETID']; ?>)" class="btn btn-cancel">
                                    Cancel
                                </button>
                            </div>
                        </form>
                    </div>
                    <?php endif; ?>
                </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>

        <p style="text-align: center; margin: 20px 0;">
            <a href="dashboard.php" style="color: white; text-decoration: none; font-weight: 600;">← Back to Dashboard</a>
        </p>
    </div>

    <script>
        function toggleResolutionForm(ticketId) {
            const form = document.getElementById('resolve_' + ticketId);
            if (form.classList.contains('active')) {
                form.classList.remove('active');
            } else {
                // Close all other forms first
                document.querySelectorAll('.resolution-form').forEach(f => {
                    f.classList.remove('active');
                });
                form.classList.add('active');
            }
        }
    </script>
</body>
</html>