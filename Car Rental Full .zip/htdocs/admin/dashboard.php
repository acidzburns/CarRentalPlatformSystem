<?php
/**
 * Admin Dashboard
 * Linked to external CSS file
 */

require_once '../config/database.php';
require_once '../config/session.php';
require_once '../includes/check_auth.php';

// Check if user is logged in as admin
check_authentication('admin');

// Get admin information
$admin_name = get_user_name();

// --- STATISTICS ---
// 1. Pending Lessors
$sql_pending = "SELECT COUNT(*) as total FROM LESSOR WHERE VERIFICATION_STATUS = 'PENDING'";
$pending_result = db_fetch_one($sql_pending);
$total_pending_lessors = $pending_result ? $pending_result['TOTAL'] : 0;

// 2. Open Tickets
$sql_tickets = "SELECT COUNT(*) as total FROM TICKET WHERE STATUS = 'OPEN'";
$tickets_result = db_fetch_one($sql_tickets);
$total_tickets = $tickets_result ? $tickets_result['TOTAL'] : 0;

// 3. Total Renters
$sql_renters = "SELECT COUNT(*) as total FROM RENTER";
$renters_result = db_fetch_one($sql_renters);
$total_renters = $renters_result ? $renters_result['TOTAL'] : 0;

// 4. Active Lessors
$sql_lessors = "SELECT COUNT(*) as total FROM LESSOR WHERE VERIFICATION_STATUS = 'VERIFIED'";
$lessors_result = db_fetch_one($sql_lessors);
$total_verified_lessors = $lessors_result ? $lessors_result['TOTAL'] : 0;

// 5. Total Cars
$sql_cars = "SELECT COUNT(*) as total FROM CAR";
$cars_result = db_fetch_one($sql_cars);
$total_cars = $cars_result ? $cars_result['TOTAL'] : 0;

// 6. Total Bookings
$sql_bookings = "SELECT COUNT(*) as total FROM BOOKING";
$bookings_result = db_fetch_one($sql_bookings);
$total_bookings = $bookings_result ? $bookings_result['TOTAL'] : 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    
    <link href="../assets/css/admin-dashboard.css" rel="stylesheet">
</head>
<body>

    <div class="sidebar">
        <h4><i class="fas fa-car-side"></i> Admin Panel</h4>
        
        <a href="dashboard.php" style="background: rgba(255,255,255,0.1); color: white; border-left: 4px solid #3b82f6;">
            <i class="fas fa-tachometer-alt"></i> Dashboard
        </a>
        
        <a href="verify_lessors.php">
            <i class="fas fa-user-check"></i> Verify Lessors
            <?php if ($total_pending_lessors > 0): ?>
                <span style="background: #f59e0b; padding: 2px 6px; border-radius: 4px; font-size: 10px; margin-left: auto; color: black;">
                    <?php echo $total_pending_lessors; ?>
                </span>
            <?php endif; ?>
        </a>
        
        <a href="manage_users.php">
            <i class="fas fa-users"></i> Manage Users
        </a>
        
        <a href="manage_bookings.php">
            <i class="fas fa-calendar-alt"></i> Bookings
        </a>
        
        <a href="manage_tickets.php">
            <i class="fas fa-headset"></i> Support
            <?php if ($total_tickets > 0): ?>
                <span style="background: #ef4444; padding: 2px 6px; border-radius: 4px; font-size: 10px; margin-left: auto; color: white;">
                    <?php echo $total_tickets; ?>
                </span>
            <?php endif; ?>
        </a>
        
        <a href="reports.php">
            <i class="fas fa-chart-line"></i> Reports
        </a>

        <a href="../auth/logout.php" class="text-danger">
            <i class="fas fa-sign-out-alt"></i> Logout
        </a>
    </div>

    <div class="main-content">
        
        <div class="d-flex" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px;">
            <div>
                <h2>Dashboard Overview</h2>
                <p class="text-muted">Welcome back, <?php echo htmlspecialchars($admin_name); ?></p>
            </div>
            <div>
                <span style="background: white; padding: 8px 16px; border-radius: 20px; box-shadow: 0 2px 5px rgba(0,0,0,0.05); font-weight: 500;">
                    <i class="fas fa-user-circle"></i> Admin
                </span>
            </div>
        </div>

        <?php if ($total_pending_lessors > 0 || $total_tickets > 0): ?>
        <div style="margin-bottom: 30px;">
            <h6 style="color: #64748b; font-weight: bold; margin-bottom: 15px; text-transform: uppercase; font-size: 12px;">Action Required</h6>
            <div class="row">
                <?php if ($total_pending_lessors > 0): ?>
                <div class="col-md-3">
                    <div class="stat-card border-warning" style="cursor: pointer;" onclick="window.location='verify_lessors.php'">
                        <h6>Pending Verifications</h6>
                        <h3 style="color: #d97706;"><?php echo $total_pending_lessors; ?></h3>
                        <p style="font-size: 13px; color: #666; margin-bottom: 0;">New lessors waiting</p>
                    </div>
                </div>
                <?php endif; ?>

                <?php if ($total_tickets > 0): ?>
                <div class="col-md-3">
                    <div class="stat-card border-danger" style="border-left: 4px solid #ef4444 !important; cursor: pointer;" onclick="window.location='manage_tickets.php'">
                        <h6>Open Tickets</h6>
                        <h3 style="color: #ef4444;"><?php echo $total_tickets; ?></h3>
                        <p style="font-size: 13px; color: #666; margin-bottom: 0;">Support requests</p>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
        <?php endif; ?>

        <h6 style="color: #64748b; font-weight: bold; margin-bottom: 15px; text-transform: uppercase; font-size: 12px;">System Statistics</h6>
        <div class="row">
            <div class="col-md-3">
                <div class="stat-card border-primary">
                    <div style="display: flex; justify-content: space-between;">
                        <div>
                            <h6>Total Renters</h6>
                            <h3><?php echo $total_renters; ?></h3>
                        </div>
                        <i class="fas fa-users" style="font-size: 24px; color: #3b82f6; opacity: 0.2;"></i>
                    </div>
                </div>
            </div>

            <div class="col-md-3">
                <div class="stat-card border-success">
                    <div style="display: flex; justify-content: space-between;">
                        <div>
                            <h6>Active Lessors</h6>
                            <h3><?php echo $total_verified_lessors; ?></h3>
                        </div>
                        <i class="fas fa-user-check" style="font-size: 24px; color: #10b981; opacity: 0.2;"></i>
                    </div>
                </div>
            </div>

            <div class="col-md-3">
                <div class="stat-card border-info">
                    <div style="display: flex; justify-content: space-between;">
                        <div>
                            <h6>Total Cars</h6>
                            <h3><?php echo $total_cars; ?></h3>
                        </div>
                        <i class="fas fa-car" style="font-size: 24px; color: #06b6d4; opacity: 0.2;"></i>
                    </div>
                </div>
            </div>

            <div class="col-md-3">
                <div class="stat-card border-warning">
                    <div style="display: flex; justify-content: space-between;">
                        <div>
                            <h6>Total Bookings</h6>
                            <h3><?php echo $total_bookings; ?></h3>
                        </div>
                        <i class="fas fa-bookmark" style="font-size: 24px; color: #f59e0b; opacity: 0.2;"></i>
                    </div>
                </div>
            </div>
        </div>

        <h6 style="color: #64748b; font-weight: bold; margin-top: 30px; margin-bottom: 15px; text-transform: uppercase; font-size: 12px;">Quick Actions</h6>
        <div class="row">
            <div class="col-md-3">
                <a href="verify_lessors.php" style="text-decoration: none;">
                    <div class="stat-card" style="text-align: center; padding: 20px;">
                        <i class="fas fa-id-card" style="font-size: 24px; color: #64748b; margin-bottom: 10px;"></i>
                        <h6 style="margin: 0; color: #333;">Verify Lessors</h6>
                    </div>
                </a>
            </div>
            
            <div class="col-md-3">
                <a href="manage_users.php" style="text-decoration: none;">
                    <div class="stat-card" style="text-align: center; padding: 20px;">
                        <i class="fas fa-users-cog" style="font-size: 24px; color: #64748b; margin-bottom: 10px;"></i>
                        <h6 style="margin: 0; color: #333;">Manage Users</h6>
                    </div>
                </a>
            </div>

            <div class="col-md-3">
                <a href="reports.php" style="text-decoration: none;">
                    <div class="stat-card" style="text-align: center; padding: 20px;">
                        <i class="fas fa-file-invoice" style="font-size: 24px; color: #64748b; margin-bottom: 10px;"></i>
                        <h6 style="margin: 0; color: #333;">System Reports</h6>
                    </div>
                </a>
            </div>
        </div>

    </div>

</body>
</html>