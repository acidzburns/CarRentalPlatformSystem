<?php
/**
 * UC13: Support Ticket Submission (Renter)
 */
session_start();
require_once '../config/database.php';
require_once '../config/session.php';
require_once '../includes/check_auth.php';
require_once '../config/email_test.php';

check_authentication('renter');

$renter_id = get_user_id();
$renter_name = get_user_name();

/* ---------- HANDLE FORM SUBMISSION ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'submit') {
    $subject = trim($_POST['subject']);
    $description = trim($_POST['description']);
    $category = $_POST['category'] ?? 'General';

    if (empty($subject) || empty($description)) {
        $_SESSION['error'] = 'Please fill in all required fields.';
    } else {

        $admin = db_fetch_one("SELECT ADMINID FROM ADMIN WHERE ROWNUM = 1");
        $admin_id = $admin['ADMINID'] ?? 1;

        $ticket_seq = db_fetch_one("SELECT SEQ_TICKET.NEXTVAL AS NEXTVAL FROM DUAL");
        $ticket_id = $ticket_seq['NEXTVAL'];

        $insert = "INSERT INTO TICKET 
                  (TICKETID, ADMINID, RENTERID, LESSORID, SUBJECT, DESCRIPTION, STATUS, CREATED_AT)
                  VALUES 
                  (:ticketid, :adminid, :renterid, NULL, :subject, :description, 'OPEN', SYSDATE)";

        if (db_execute($insert, [
            'ticketid' => $ticket_id,
            'adminid' => $admin_id,
            'renterid' => $renter_id,
            'subject' => $subject,
            'description' => $description
        ])) {

            $_SESSION['success'] = "Ticket submitted successfully! Ref: TICKET-$ticket_id";

            $admin_email = db_fetch_one(
                "SELECT EMAIL FROM ADMIN WHERE ADMINID = :id",
                ['id' => $admin_id]
            )['EMAIL'] ?? null;

            if ($admin_email) {
                send_email(
                    $admin_email,
                    "New Support Ticket: TICKET-$ticket_id",
                    "<p><strong>Renter:</strong> $renter_name</p>
                     <p><strong>Subject:</strong> $subject</p>
                     <p><strong>Description:</strong><br>" . nl2br($description) . "</p>"
                );
            }

            header('Location: submit_ticket.php');
            exit;
        } else {
            $_SESSION['error'] = 'Submission failed. Try again.';
        }
    }
}

/* ---------- FETCH TICKETS ---------- */
$tickets = db_fetch_all(
    "SELECT t.*, 
     TO_CHAR(t.CREATED_AT, 'DD-MON-YYYY HH24:MI') AS CREATED_AT_F,
     a.NAME AS ADMIN_NAME
     FROM TICKET t
     LEFT JOIN ADMIN a ON t.ADMINID = a.ADMINID
     WHERE t.RENTERID = :id
     ORDER BY t.CREATED_AT DESC",
    ['id' => $renter_id]
);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Support Center</title>
    <link rel="stylesheet" href="/assets/css/support_ticket.css">
</head>
<body>

<div class="container">
    <header>
        <h1>Support Center</h1>
        <p>Welcome, <?= htmlspecialchars($renter_name) ?></p>
        <nav>
            <a href="dashboard.php">Dashboard</a>
            <a href="../auth/logout.php" class="logout">Logout</a>
        </nav>
    </header>

    <?php if (isset($_SESSION['success'])): ?>
        <div class="alert success"><?= $_SESSION['success']; unset($_SESSION['success']); ?></div>
    <?php endif; ?>

    <?php if (isset($_SESSION['error'])): ?>
        <div class="alert error"><?= $_SESSION['error']; unset($_SESSION['error']); ?></div>
    <?php endif; ?>

    <section class="card">
        <h2>Submit New Ticket</h2>

        <form method="POST">
            <input type="hidden" name="action" value="submit">

            <label>Category</label>
            <select name="category">
                <option>General</option>
                <option>Booking</option>
                <option>Payment</option>
                <option>Account</option>
                <option>Technical</option>
                <option>Other</option>
            </select>

            <label>Subject *</label>
            <input type="text" name="subject" required>

            <label>Description *</label>
            <textarea name="description" rows="5" required></textarea>

            <button type="submit">Submit Ticket</button>
        </form>
    </section>

    <section class="card">
        <h2>My Tickets (<?= count($tickets) ?>)</h2>

        <?php if (!$tickets): ?>
            <p class="empty">No tickets submitted yet.</p>
        <?php else: ?>
            <?php foreach ($tickets as $t): ?>
                <div class="ticket">
                    <div class="ticket-header">
                        <strong>TICKET-<?= $t['TICKETID'] ?></strong>
                        <span class="status <?= strtolower($t['STATUS']) ?>">
                            <?= $t['STATUS'] ?>
                        </span>
                    </div>

                    <p class="subject"><?= htmlspecialchars($t['SUBJECT']) ?></p>
                    <p class="meta">
                        Submitted: <?= $t['CREATED_AT_F'] ?> |
                        Admin: <?= htmlspecialchars($t['ADMIN_NAME'] ?? 'Unassigned') ?>
                    </p>

                    <div class="description">
                        <?= nl2br(htmlspecialchars($t['DESCRIPTION'])) ?>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </section>
</div>

</body>
</html>
