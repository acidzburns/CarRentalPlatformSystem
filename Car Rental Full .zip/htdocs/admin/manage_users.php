<?php
/**
 * UC23: Manage Users (SRS Pages 79-82)
 * Admin manages all user accounts (renters and lessors)
 */

require_once '../config/database.php';
require_once '../config/session.php';

// Check if admin is logged in
require_login('admin');

$adminid = get_user_id();
$errors = [];
$success = "";

// Get filters from URL
$user_type_filter = isset($_GET['type']) ? $_GET['type'] : 'all';
$status_filter = isset($_GET['status']) ? $_GET['status'] : 'all';
$search_query = isset($_GET['search']) ? trim($_GET['search']) : '';

// UC23 Step 2: Retrieve and display list of all users
$users = [];

// ✅ IMPROVED FILTER LOGIC - Works for both renters and lessors
$fetch_renters = false;
$fetch_lessors = false;

if ($user_type_filter == 'all') {
    $fetch_renters = true;
    $fetch_lessors = true;
} elseif ($user_type_filter == 'renter') {
    $fetch_renters = true;
} elseif ($user_type_filter == 'lessor') {
    $fetch_lessors = true;
}

// Fetch Renters
if ($fetch_renters) {
    $renter_sql = "SELECT RENTERID as USER_ID, NAME, EMAIL, PHONE, CREATED_AT, 
                   'RENTER' as USER_TYPE, NVL(STATUS, 'ACTIVE') as STATUS,
                   TO_CHAR(CREATED_AT, 'DD-MON-YYYY') as CREATED_FMT
                   FROM RENTER
                   WHERE 1=1";
    
    // ✅ NEW: Apply status filter to renters too
    if ($status_filter == 'active') {
        $renter_sql .= " AND NVL(STATUS, 'ACTIVE') = 'ACTIVE'";
    } elseif ($status_filter == 'suspended') {
        $renter_sql .= " AND STATUS = 'SUSPENDED'";
    }
    // Skip renters if filtering by lessor-specific statuses
    elseif (in_array($status_filter, ['verified', 'pending', 'rejected'])) {
        $fetch_renters = false;
    }
    
    // UC23 Step 4: Search functionality
    if ($fetch_renters && !empty($search_query)) {
        $renter_sql .= " AND (LOWER(NAME) LIKE LOWER(:search) 
                        OR LOWER(EMAIL) LIKE LOWER(:search2) 
                        OR PHONE LIKE :search3)";
    }
    
    if ($fetch_renters) {
        $renter_sql .= " ORDER BY CREATED_AT DESC";
        
        $stmt_renter = oci_parse($conn, $renter_sql);
        
        if (!empty($search_query)) {
            $search_param = '%' . $search_query . '%';
            oci_bind_by_name($stmt_renter, ':search', $search_param);
            oci_bind_by_name($stmt_renter, ':search2', $search_param);
            oci_bind_by_name($stmt_renter, ':search3', $search_param);
        }
        
        oci_execute($stmt_renter);
        
        while ($row = oci_fetch_assoc($stmt_renter)) {
            $users[] = $row;
        }
    }
}

// Fetch Lessors
if ($fetch_lessors) {
    $lessor_sql = "SELECT LESSORID as USER_ID, NAME, EMAIL, PHONE, CREATED_AT,
                   'LESSOR' as USER_TYPE, VERIFICATION_STATUS as STATUS,
                   TO_CHAR(CREATED_AT, 'DD-MON-YYYY') as CREATED_FMT
                   FROM LESSOR
                   WHERE 1=1";
    
    // UC23 Step 3: Filter by status
    if ($status_filter == 'verified') {
        $lessor_sql .= " AND VERIFICATION_STATUS = 'VERIFIED'";
    } elseif ($status_filter == 'pending') {
        $lessor_sql .= " AND VERIFICATION_STATUS = 'PENDING'";
    } elseif ($status_filter == 'rejected') {
        $lessor_sql .= " AND VERIFICATION_STATUS = 'REJECTED'";
    } elseif ($status_filter == 'suspended') {
        $lessor_sql .= " AND VERIFICATION_STATUS = 'SUSPENDED'";
    }
    // Skip lessors if filtering by active (renter-specific)
    elseif ($status_filter == 'active') {
        $fetch_lessors = false;
    }
    
    // UC23 Step 4: Search functionality
    if ($fetch_lessors && !empty($search_query)) {
        $lessor_sql .= " AND (LOWER(NAME) LIKE LOWER(:search) 
                        OR LOWER(EMAIL) LIKE LOWER(:search2) 
                        OR PHONE LIKE :search3)";
    }
    
    if ($fetch_lessors) {
        $lessor_sql .= " ORDER BY CREATED_AT DESC";
        
        $stmt_lessor = oci_parse($conn, $lessor_sql);
        
        if (!empty($search_query)) {
            $search_param = '%' . $search_query . '%';
            oci_bind_by_name($stmt_lessor, ':search', $search_param);
            oci_bind_by_name($stmt_lessor, ':search2', $search_param);
            oci_bind_by_name($stmt_lessor, ':search3', $search_param);
        }
        
        oci_execute($stmt_lessor);
        
        while ($row = oci_fetch_assoc($stmt_lessor)) {
            $users[] = $row;
        }
    }
}

// Get user statistics
$stats = [
    'total_renters' => 0,
    'active_renters' => 0,
    'suspended_renters' => 0,
    'total_lessors' => 0,
    'verified_lessors' => 0,
    'pending_lessors' => 0,
    'rejected_lessors' => 0,
    'suspended_lessors' => 0
];

// Count renters by status
$renter_count_sql = "SELECT 
                     COUNT(*) as TOTAL,
                     COUNT(CASE WHEN NVL(STATUS, 'ACTIVE') = 'ACTIVE' THEN 1 END) as ACTIVE,
                     COUNT(CASE WHEN STATUS = 'SUSPENDED' THEN 1 END) as SUSPENDED
                     FROM RENTER";
$stmt_rcount = oci_parse($conn, $renter_count_sql);
oci_execute($stmt_rcount);
$rcount = oci_fetch_assoc($stmt_rcount);
$stats['total_renters'] = $rcount['TOTAL'];
$stats['active_renters'] = $rcount['ACTIVE'];
$stats['suspended_renters'] = $rcount['SUSPENDED'];

// Count lessors by status
$lessor_count_sql = "SELECT 
                     COUNT(*) as TOTAL,
                     COUNT(CASE WHEN VERIFICATION_STATUS = 'VERIFIED' THEN 1 END) as VERIFIED,
                     COUNT(CASE WHEN VERIFICATION_STATUS = 'PENDING' THEN 1 END) as PENDING,
                     COUNT(CASE WHEN VERIFICATION_STATUS = 'REJECTED' THEN 1 END) as REJECTED,
                     COUNT(CASE WHEN VERIFICATION_STATUS = 'SUSPENDED' THEN 1 END) as SUSPENDED
                     FROM LESSOR";
$stmt_lcount = oci_parse($conn, $lessor_count_sql);
oci_execute($stmt_lcount);
$lcount = oci_fetch_assoc($stmt_lcount);
$stats['total_lessors'] = $lcount['TOTAL'];
$stats['verified_lessors'] = $lcount['VERIFIED'];
$stats['pending_lessors'] = $lcount['PENDING'];
$stats['rejected_lessors'] = $lcount['REJECTED'];
$stats['suspended_lessors'] = $lcount['SUSPENDED'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Users - Admin</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/manage_users.css">
</head>
<body>
    <div class="container">
        <!-- Header -->
        <div class="header">
            <h1>👥 Manage Users</h1>
            <nav class="nav">
                <a href="dashboard.php">Dashboard</a>
                <a href="verify_lessors.php">Verify Lessors</a>
                <a href="manage_users.php" class="active">Manage Users</a>
                <a href="manage_tickets.php">Support Tickets</a>
                <a href="reports.php">Reports</a>
                <a href="../auth/logout.php">Logout</a>
            </nav>
        </div>

        <!-- Flash Messages -->
        <?php if (function_exists('display_flash_message')): ?>
            <?php display_flash_message(); ?>
        <?php endif; ?>

        <!-- Display errors -->
        <?php if (!empty($errors)): ?>
            <div class="alert error">
                <strong>❌ Error:</strong>
                <ul style="margin: 10px 0 0 20px;">
                    <?php foreach ($errors as $error): ?>
                        <li><?php echo htmlspecialchars($error); ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <!-- Statistics Cards -->
        <div class="stats-grid">
            <!-- Renters Card -->
            <div class="stat-card">
                <div class="stat-header">
                    <div class="stat-icon renters">👤</div>
                    <div class="stat-title">Renters</div>
                </div>
                <div class="stat-content">
                    <div class="stat-item">
                        <div class="stat-value"><?php echo $stats['total_renters']; ?></div>
                        <div class="stat-label">Total</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-value" style="color: #48bb78;"><?php echo $stats['active_renters']; ?></div>
                        <div class="stat-label">Active</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-value" style="color: #f56565;"><?php echo $stats['suspended_renters']; ?></div>
                        <div class="stat-label">Suspended</div>
                    </div>
                </div>
            </div>

            <!-- Lessors Card -->
            <div class="stat-card">
                <div class="stat-header">
                    <div class="stat-icon lessors">🏠</div>
                    <div class="stat-title">Lessors</div>
                </div>
                <div class="stat-content">
                    <div class="stat-item">
                        <div class="stat-value"><?php echo $stats['total_lessors']; ?></div>
                        <div class="stat-label">Total</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-value" style="color: #48bb78;"><?php echo $stats['verified_lessors']; ?></div>
                        <div class="stat-label">Verified</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-value" style="color: #ed8936;"><?php echo $stats['pending_lessors']; ?></div>
                        <div class="stat-label">Pending</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-value" style="color: #f56565;"><?php echo $stats['rejected_lessors']; ?></div>
                        <div class="stat-label">Rejected</div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Filter Section -->
        <div class="filter-section">
            <h2>🔍 Filter & Search Users</h2>
            <form method="GET" action="">
                <div class="filter-grid">
                    <div class="filter-group">
                        <label for="user-type">User Type</label>
                        <select name="type" id="user-type">
                            <option value="all" <?php echo $user_type_filter == 'all' ? 'selected' : ''; ?>>All Users</option>
                            <option value="renter" <?php echo $user_type_filter == 'renter' ? 'selected' : ''; ?>>Renters Only</option>
                            <option value="lessor" <?php echo $user_type_filter == 'lessor' ? 'selected' : ''; ?>>Lessors Only</option>
                        </select>
                    </div>

                    <div class="filter-group">
                        <label for="status">Status</label>
                        <select name="status" id="status">
                            <option value="all" <?php echo $status_filter == 'all' ? 'selected' : ''; ?>>All Status</option>
                            <optgroup label="Common Status">
                                <option value="suspended" <?php echo $status_filter == 'suspended' ? 'selected' : ''; ?>>🚫 Suspended (Both)</option>
                            </optgroup>
                            <optgroup label="Renter Status">
                                <option value="active" <?php echo $status_filter == 'active' ? 'selected' : ''; ?>>✓ Active (Renters)</option>
                            </optgroup>
                            <optgroup label="Lessor Status">
                                <option value="verified" <?php echo $status_filter == 'verified' ? 'selected' : ''; ?>>✓ Verified (Lessors)</option>
                                <option value="pending" <?php echo $status_filter == 'pending' ? 'selected' : ''; ?>>⏳ Pending (Lessors)</option>
                                <option value="rejected" <?php echo $status_filter == 'rejected' ? 'selected' : ''; ?>>✗ Rejected (Lessors)</option>
                            </optgroup>
                        </select>
                    </div>

                    <div class="filter-group">
                        <label for="search">Search</label>
                        <input type="text" name="search" id="search" value="<?php echo htmlspecialchars($search_query); ?>" placeholder="Name, email, or phone...">
                    </div>
                </div>

                <div class="filter-actions">
                    <button type="submit" class="btn btn-primary">
                        🔍 Apply Filters
                    </button>
                    <a href="manage_users.php" class="btn btn-secondary">Clear Filters</a>
                </div>
            </form>
        </div>

        <!-- Users Table -->
        <div class="users-section">
            <h2>👥 All Users (<?php echo count($users); ?>)</h2>
            
            <?php if (empty($users)): ?>
                <div class="empty-state">
                    <svg fill="currentColor" viewBox="0 0 20 20">
                        <path d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z"/>
                    </svg>
                    <p>No users found matching your filters.</p>
                </div>
            <?php else: ?>
                <div class="table-container">
                    <table>
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Type</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Phone</th>
                                <th>Status</th>
                                <th>Joined</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($users as $user): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($user['USER_ID']); ?></td>
                                    <td>
                                        <span class="user-type-badge <?php echo strtolower($user['USER_TYPE']); ?>">
                                            <?php echo htmlspecialchars($user['USER_TYPE']); ?>
                                        </span>
                                    </td>
                                    <td><?php echo htmlspecialchars($user['NAME']); ?></td>
                                    <td><?php echo htmlspecialchars($user['EMAIL']); ?></td>
                                    <td><?php echo htmlspecialchars($user['PHONE'] ?? 'N/A'); ?></td>
                                    <td>
                                        <span class="status-badge <?php echo strtolower($user['STATUS']); ?>">
                                            <?php 
                                            if ($user['USER_TYPE'] == 'RENTER' && $user['STATUS'] == 'ACTIVE') {
                                                echo '✓ ' . $user['STATUS'];
                                            } elseif ($user['STATUS'] == 'SUSPENDED') {
                                                echo '🚫 ' . $user['STATUS'];
                                            } elseif ($user['STATUS'] == 'PENDING') {
                                                echo '⏳ ' . $user['STATUS'];
                                            } elseif ($user['STATUS'] == 'VERIFIED') {
                                                echo '✓ ' . $user['STATUS'];
                                            } elseif ($user['STATUS'] == 'REJECTED') {
                                                echo '✗ ' . $user['STATUS'];
                                            } else {
                                                echo htmlspecialchars($user['STATUS']);
                                            }
                                            ?>
                                        </span>
                                    </td>
                                    <td><?php echo htmlspecialchars($user['CREATED_FMT']); ?></td>
                                    <td>
                                        <div class="action-links">
                                            <a href="view_user.php?type=<?php echo strtolower($user['USER_TYPE']); ?>&id=<?php echo $user['USER_ID']; ?>">
                                                View
                                            </a>
                                            <a href="edit_user.php?type=<?php echo strtolower($user['USER_TYPE']); ?>&id=<?php echo $user['USER_ID']; ?>">
                                                Edit
                                            </a>
                                            
                                            <?php if ($user['USER_TYPE'] == 'LESSOR'): ?>
                                                <?php if ($user['STATUS'] == 'VERIFIED'): ?>
                                                    <a href="suspend_user.php?type=lessor&id=<?php echo $user['USER_ID']; ?>" 
                                                       onclick="return confirm('Suspend this lessor account?')" 
                                                       class="danger">
                                                        Suspend
                                                    </a>
                                                <?php elseif ($user['STATUS'] == 'SUSPENDED'): ?>
                                                    <a href="unsuspend_user.php?type=lessor&id=<?php echo $user['USER_ID']; ?>" 
                                                       onclick="return confirm('Reactivate this account?')" 
                                                       class="success">
                                                        Reactivate
                                                    </a>
                                                <?php endif; ?>
                                            <?php elseif ($user['USER_TYPE'] == 'RENTER'): ?>
                                                <?php if ($user['STATUS'] == 'ACTIVE'): ?>
                                                    <a href="suspend_user.php?type=renter&id=<?php echo $user['USER_ID']; ?>" 
                                                       onclick="return confirm('Suspend this renter account?')" 
                                                       class="danger">
                                                        Suspend
                                                    </a>
                                                <?php elseif ($user['STATUS'] == 'SUSPENDED'): ?>
                                                    <a href="unsuspend_user.php?type=renter&id=<?php echo $user['USER_ID']; ?>" 
                                                       onclick="return confirm('Reactivate this account?')" 
                                                       class="success">
                                                        Reactivate
                                                    </a>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>

        <!-- Info Box -->
        <div class="info-box">
            <h3>ℹ️ User Management Guidelines</h3>
            <ul>
                <li><strong>View:</strong> See complete user information and activity history</li>
                <li><strong>Edit:</strong> Update user contact information (name, email, phone)</li>
                <li><strong>Suspend:</strong> Temporarily block user access (for violations or disputes)</li>
                <li><strong>Reactivate:</strong> Restore access to suspended accounts</li>
                <li><strong>Renters:</strong> Can be Active or Suspended</li>
                <li><strong>Lessors:</strong> Can be Verified, Pending, Rejected, or Suspended</li>
            </ul>
        </div>

        <p style="text-align: center; margin: 20px 0;">
            <a href="dashboard.php" style="color: white; text-decoration: none; font-weight: 600;">← Back to Dashboard</a>
        </p>
    </div>
</body>
</html>